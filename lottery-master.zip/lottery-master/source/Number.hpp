#ifndef LOTTERY_NUMBER_HPP
#define LOTTERY_NUMBER_HPP


namespace lottery
{


    /**
        Lottery number.
     */
    typedef int Number;


} //namespace lottery


#endif //LOTTERY_NUMBER_HPP
