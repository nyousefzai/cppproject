# lottery
Personal lottery prediction program and library.
